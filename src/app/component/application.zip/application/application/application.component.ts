import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { DomSanitizer } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import { FormlyFieldConfig } from '@ngx-formly/core';
import { FormService } from 'src/app/services/form.service';


@Component({
  selector: 'app-application',
  templateUrl: './application.component.html',
  styleUrls: ['./application.component.css']
})
export class ApplicationComponent implements OnInit{
  @ViewChild('attachments') attachment: any;
  imagePreview=""
  fileList: File[] = [];
  listOfFiles: any[] = [];
  isLoading = false;
  appForm!:FormGroup
  selected = 'option1';
  form = new FormGroup({});
  pageHeading: any
  formAction = 'Add'
  butText = 'Save'
  id: any
  keyField: any
  isDataError = false
  config: any = {}
  authdata: any
  options: any = {};
  fields!: FormlyFieldConfig[]
  fields1: any[] = [];
  uploadedFiles:any
  url:any
  @Input('formName') formName: any
  @Input('mode') mode: string = "page"
  @Input('model') model: any = {}
  @Output('onClose') onClose = new EventEmitter<any>();
  displayURL;
  videocntrl!: FormGroup
  videoUrl: string = '';
  video: any; 
  cf: any;
  
constructor(
  private formBuilder: FormBuilder,

  private formService: FormService,
  private sanitizer: DomSanitizer

  
){
  this.displayURL = sanitizer.bypassSecurityTrustResourceUrl('this.url');
}




ngOnInit(): void {
  this.appForm = this.formBuilder.group({
    app_code: ['', [Validators.required,
    Validators.maxLength(30)]],
    app_category: new FormControl('', [Validators.pattern("^[a-z A-Z 0-9 \s]*$"), Validators.required, Validators.maxLength(30)]),
    org_id: new FormControl(''),
    default_label: new FormControl('', [Validators.required]),
    default_image_url: new FormControl(''),
    is_variant_flag: new FormControl('', [Validators.pattern("^[0-9]*$"), Validators.required, Validators.minLength(10)])
  })

}
ngOnChanges(changes: SimpleChanges) {
}

frmSubmit(data: any) {
  debugger
  this.formService.saveFormData(data).then((result: any) => {
    if (result != undefined) {
      // this.goBack(result)
    }
  })
}

initLoad() {
  this.formService.LoadInitData(this)
}

viewHdVideo(event:any){
  debugger
 this.url = event
}

// goBack(data?: any) {
//   if (this.config.mode == 'page') {
//     this.router.navigate([`${this.config.onCancelRoute}`]);
//   } else if (this.mode == 'popup') {
//     if (data) {
//       this.onClose.emit(data)
//     } else {
//       this.onClose.emit({ action: this.formAction, data: this.model })
//     }
//     return
//   }
// }

// resetBtn(data?: any) {
//   this.model = {}
//   this.formAction = this.model.id ? 'cancel' : 'Add'
//   this.butText = this.model.id ? 'cancel' : 'Save';
// }
onUpload(event:any) {
  for(let file of event.files) {
      this.uploadedFiles.push(file);
  }

  // this.messageService.add({severity: 'info', summary: 'File Uploaded', detail: ''});
}
 displayVideo(event:any) { 
  debugger
  this.video = this.sanitizer.bypassSecurityTrustHtml(` <iframe width="560" height="315" src="${this.videoUrl}" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe> `); } 


  addField() {
    debugger
    this.fields1.push('');
  }
  removeField(index: number) {
    this.fields1.splice(index, 1);
  }
  
  onFileChanged(event: any) {
    this.isLoading = true;
    for (var i = 0; i <= event.target.files.length - 1; i++) {
      var selectedFile = event.target.files[i];
      if (this.listOfFiles.indexOf(selectedFile.name) === -1) {
        this.fileList.push(selectedFile);
        this.listOfFiles.push(selectedFile.name);
      }
    }

    this.isLoading = false;

    //this.attachment.nativeElement.value = '';
  }

  removeSelectedFile(index:any) {
    // Delete the item from fileNames list
    this.listOfFiles.splice(index, 1);
    // delete file from FileList
    this.fileList.splice(index, 1);
  }

  public file: any;
  urls: any[] = [];
  multiples: any[] = [];
  onSelectFile(event:any) {
    this.file = event.target.files && event.target.files.length;
    if (this.file > 0 && this.file < 5) {
      let i: number = 0;
      for (const singlefile of event.target.files) {
        var reader = new FileReader();
        reader.readAsDataURL(singlefile);
        this.urls.push(singlefile);
        this.cf.detectChanges();
        i++;
        console.log(this.urls);
        reader.onload = (event) => {
          const url = (<FileReader>event.target).result as string;
          this.multiples.push(url);
          this.cf.detectChanges();
        };
        console.log(singlefile);
      }
    }
    // else {
    //   this.toast.error('No More than 4 images', 'Upload Images')
    // }
  }
  selectedFiles!: FileList;
  imageUrls: string[] = [];

  onFileInputChange(event: any) {
    this.selectedFiles = event.target.files;
    this.displaySelectedImages();
  }

  displaySelectedImages() {
    for (let i = 0; i < this.selectedFiles.length; i++) {
      const reader = new FileReader();
      reader.readAsDataURL(this.selectedFiles[i]);
      reader.onload = () => {
        this.imageUrls.push(reader.result as string);
      }
    }
  }
}
